#include<iostream>
#include<conio.h>
#include<string>
using namespace std;
int main()
{
	for(int i=1; i<=5; i++)
	{
		for(int j=1; j<=7; j++)
		if(j==1 || j==5 || (i==3 && j==3) || (i==4 && j==2) || (i==4 && j==4))
		cout<<"'";
		else
		cout<<" ";
		cout<<endl;
	}
}